@extends('layouts.app')
@section('title', 'Edit Barang - StokKos')

@section('content')
<div class="max-w-xl mx-auto bg-panel p-6 sm:p-8 rounded-3xl border border-line space-y-5">
    <div class="border-b border-line pb-4">
        <h2 class="text-xl font-black text-white">Edit Data Barang</h2>
        <p class="text-xs text-slate-400 mt-1">Divalidasi di <code class="text-brand-light font-mono">BarangController@update</code> sebelum diperbarui.</p>
    </div>
    <form action="{{ route('barangs.update', $barang->id) }}" method="POST" class="space-y-4" novalidate>
        @csrf
        @method('PUT')
        @include('barangs._form')
    </form>
</div>
@endsection
