@extends('layouts.app')
@section('title', 'Daftar Barang - StokKos')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-line">
        <div>
            <h2 class="text-2xl font-black text-white">Inventaris Kos</h2>
            <p class="text-xs text-slate-400 mt-1">Alur: Route &rarr; <code class="text-brand-light font-mono">BarangController@index</code> &rarr; Eloquent &rarr; View</p>
        </div>
        <a href="{{ route('barangs.create') }}" class="px-4 py-2.5 rounded-xl bg-brand hover:bg-brand-light text-ink text-xs font-bold transition w-fit">+ Tambah Barang Baru</a>
    </div>

    <div class="overflow-x-auto rounded-2xl border border-line bg-panel">
        <table class="w-full text-left text-sm text-slate-300">
            <thead class="bg-ink/60 text-xs text-slate-400 border-b border-line">
                <tr>
                    <th class="py-3.5 px-4 text-center w-16">No</th>
                    <th class="py-3.5 px-4">Nama Barang</th>
                    <th class="py-3.5 px-4">Kategori</th>
                    <th class="py-3.5 px-4 text-center">Stok</th>
                    <th class="py-3.5 px-6">Deskripsi</th>
                    <th class="py-3.5 px-4 text-center w-40">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-line">
                @forelse($barangs as $i => $b)
                @php
                    $badge = $b->stok === 0
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : ($b->stok <= 2 ? 'bg-amber-400/15 text-amber-300 border-amber-400/30' : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30');
                @endphp
                <tr class="hover:bg-line/30 transition">
                    <td class="py-4 px-4 text-center text-xs text-slate-500">{{ $i + 1 }}</td>
                    <td class="py-4 px-4 font-bold text-white">{{ $b->nama }}</td>
                    <td class="py-4 px-4"><span class="px-2 py-0.5 rounded-lg bg-line/60 text-slate-300 text-xs">{{ $b->kategori }}</span></td>
                    <td class="py-4 px-4 text-center">
                        <span class="px-2.5 py-1 rounded-full text-xs font-bold border {{ $badge }}">{{ $b->stok === 0 ? 'Habis' : $b->stok . ' ' . $b->satuan }}</span>
                    </td>
                    <td class="py-4 px-6 text-slate-400 text-xs leading-relaxed">{{ $b->deskripsi }}</td>
                    <td class="py-4 px-4">
                        <div class="flex items-center justify-center gap-2">
                            <a href="{{ route('barangs.edit', $b->id) }}" class="px-3 py-1.5 rounded-lg bg-brand/15 hover:bg-brand text-brand-light hover:text-ink border border-brand/30 text-xs font-semibold transition">Edit</a>
                            <form action="{{ route('barangs.destroy', $b->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold transition">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center py-8 text-slate-500">Belum ada data. Klik <strong>+ Tambah Barang Baru</strong>.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
