{{-- Form bersama Create & Edit. Nilai lama (old) dipertahankan saat validasi gagal. --}}
@php
    $field = 'w-full px-3.5 py-2.5 rounded-xl bg-ink border text-sm text-white focus:outline-none focus:border-brand';
    $kategori = old('kategori', $barang->kategori ?? 'Makanan');
@endphp

<div>
    <label class="block text-xs font-bold text-slate-400 mb-1">Nama Barang</label>
    <input type="text" name="nama" value="{{ old('nama', $barang->nama ?? '') }}" placeholder="Contoh: Indomie Goreng"
           class="{{ $field }} {{ $errors->has('nama') ? 'border-rose-500' : 'border-line' }}">
    @error('nama') <p class="text-xs text-rose-400 mt-1">{{ $message }}</p> @enderror
</div>

<div class="grid grid-cols-2 gap-3">
    <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">Kategori</label>
        <select name="kategori" class="{{ $field }} {{ $errors->has('kategori') ? 'border-rose-500' : 'border-line' }}">
            @foreach(['Makanan' => '🍜 Makanan & Minuman', 'Mandi' => '🧼 Mandi & Cuci', 'Kebersihan' => '🧹 Kebersihan', 'P3K' => '💊 Obat & P3K'] as $val => $label)
                <option value="{{ $val }}" @selected($kategori === $val)>{{ $label }}</option>
            @endforeach
        </select>
        @error('kategori') <p class="text-xs text-rose-400 mt-1">{{ $message }}</p> @enderror
    </div>
    <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">Stok &amp; Satuan</label>
        <div class="flex gap-2">
            <input type="number" name="stok" min="0" value="{{ old('stok', $barang->stok ?? 1) }}"
                   class="{{ $field }} {{ $errors->has('stok') ? 'border-rose-500' : 'border-line' }}">
            <input type="text" name="satuan" value="{{ old('satuan', $barang->satuan ?? 'Pcs') }}"
                   class="{{ $field }} {{ $errors->has('satuan') ? 'border-rose-500' : 'border-line' }}">
        </div>
        @error('stok') <p class="text-xs text-rose-400 mt-1">{{ $message }}</p> @enderror
        @error('satuan') <p class="text-xs text-rose-400 mt-1">{{ $message }}</p> @enderror
    </div>
</div>

<div>
    <label class="block text-xs font-bold text-slate-400 mb-1">Deskripsi Kebutuhan</label>
    <textarea name="deskripsi" rows="3" placeholder="Jelaskan kebutuhan barang ini..."
              class="{{ $field }} {{ $errors->has('deskripsi') ? 'border-rose-500' : 'border-line' }}">{{ old('deskripsi', $barang->deskripsi ?? '') }}</textarea>
    @error('deskripsi') <p class="text-xs text-rose-400 mt-1">{{ $message }}</p> @enderror
</div>

<div class="flex justify-end gap-3 pt-4 border-t border-line">
    <a href="{{ route('barangs.index') }}" class="px-4 py-2.5 rounded-xl bg-line/60 hover:bg-line text-slate-300 text-xs font-bold transition">Batal</a>
    <button type="submit" class="px-5 py-2.5 rounded-xl bg-brand hover:bg-brand-light text-ink text-xs font-bold transition">Simpan</button>
</div>
