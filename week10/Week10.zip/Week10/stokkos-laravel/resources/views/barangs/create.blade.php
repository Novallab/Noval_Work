@extends('layouts.app')
@section('title', 'Tambah Barang - StokKos')

@section('content')
<div class="max-w-xl mx-auto bg-panel p-6 sm:p-8 rounded-3xl border border-line space-y-5">
    <div class="border-b border-line pb-4">
        <h2 class="text-xl font-black text-white">Tambah Barang Baru</h2>
        <p class="text-xs text-slate-400 mt-1">Divalidasi di <code class="text-brand-light font-mono">BarangController@store</code> sebelum disimpan.</p>
    </div>
    <form action="{{ route('barangs.store') }}" method="POST" class="space-y-4" novalidate>
        @csrf
        @include('barangs._form')
    </form>
</div>
@endsection
