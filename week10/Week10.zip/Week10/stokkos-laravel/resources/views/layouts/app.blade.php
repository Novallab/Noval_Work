<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'StokKos.id')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Tema StokKos: teal (stok aman) + amber (peringatan), dasar gelap kehijauan
        tailwind.config = { theme: { extend: { colors: {
            ink: '#0d1b1a', panel: '#132523', line: '#24413e',
            brand: { DEFAULT: '#14b8a6', light: '#5eead4', dark: '#0f766e' }
        } } } };
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
    </style>
</head>
<body class="bg-ink text-slate-100 min-h-screen flex flex-col antialiased">

    <header class="bg-panel border-b border-line sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <a href="{{ route('barangs.index') }}" class="flex items-center gap-2.5 font-bold text-white text-lg">
                <span class="p-1.5 bg-brand/20 rounded-lg border border-brand/40">📦</span>
                <span>StokKos<span class="text-brand-light">.id</span></span>
                <span class="hidden sm:inline text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/30 ml-2">Week 10 &bull; Controller, Routing &amp; Validation</span>
            </a>
            <nav class="flex items-center gap-3">
                <a href="{{ route('barangs.index') }}" class="text-xs font-semibold px-3 py-2 rounded-xl bg-line/60 hover:bg-line text-slate-200 transition">Daftar Barang</a>
                <a href="{{ route('barangs.create') }}" class="text-xs font-semibold px-3.5 py-2 rounded-xl bg-brand hover:bg-brand-light text-ink transition">+ Tambah Barang</a>
            </nav>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full">
        @if(session('success'))
            <div class="mb-6 p-4 rounded-2xl bg-brand/15 border border-brand text-brand-light text-sm">{{ session('success') }}</div>
        @endif

        @yield('content')
    </main>

    <footer class="bg-panel border-t border-line py-6 text-center text-xs text-slate-400 mt-auto">
        &copy; 2026 StokKos.id &bull; Web Programming Pertemuan 10
    </footer>
</body>
</html>
