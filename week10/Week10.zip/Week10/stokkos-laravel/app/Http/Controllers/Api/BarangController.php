<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Barang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * Task 03: RESTful Barang API (response JSON + HTTP status code)
 */
class BarangController extends Controller
{
    // GET /api/barangs -> 200
    public function index()
    {
        return response()->json(['data' => Barang::all()], 200);
    }

    // POST /api/barangs -> 201 | 422
    public function store(Request $request)
    {
        $v = Validator::make($request->all(), Barang::rules(), Barang::messages());
        if ($v->fails()) {
            return $this->invalid($v);
        }

        $barang = Barang::create($v->validated());

        return response()->json(['message' => 'Berhasil', 'data' => $barang], 201);
    }

    // GET /api/barangs/{id} -> 200 | 404
    public function show($id)
    {
        $barang = Barang::find($id);

        return $barang
            ? response()->json(['data' => $barang], 200)
            : $this->notFound();
    }

    // PUT|PATCH /api/barangs/{id} -> 200 | 404 | 422
    public function update(Request $request, $id)
    {
        $barang = Barang::find($id);
        if (!$barang) {
            return $this->notFound();
        }

        $v = Validator::make($request->all(), Barang::rules(), Barang::messages());
        if ($v->fails()) {
            return $this->invalid($v);
        }

        $barang->update($v->validated());

        return response()->json(['data' => $barang], 200);
    }

    // DELETE /api/barangs/{id} -> 200 | 404
    public function destroy($id)
    {
        $barang = Barang::find($id);
        if (!$barang) {
            return $this->notFound();
        }

        $barang->delete();

        return response()->json(['message' => 'Barang berhasil dihapus.'], 200);
    }

    private function invalid($validator)
    {
        return response()->json([
            'message' => 'The given data was invalid.',
            'errors'  => $validator->errors(),
        ], 422);
    }

    private function notFound()
    {
        return response()->json(['message' => 'Barang tidak ditemukan.'], 404);
    }
}
