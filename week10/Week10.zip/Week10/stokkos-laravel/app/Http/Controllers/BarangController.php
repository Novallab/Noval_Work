<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;

/**
 * Task 01: CRUD dipindahkan ke Controller
 * Task 02: Request & Validation pada Create dan Update
 */
class BarangController extends Controller
{
    // READ
    public function index()
    {
        $barangs = Barang::all();

        return view('barangs.index', compact('barangs'));
    }

    // FORM
    public function create()
    {
        return view('barangs.create');
    }

    // CREATE (dengan validasi; gagal => kembali ke form + pesan error)
    public function store(Request $request)
    {
        $data = $request->validate(Barang::rules(), Barang::messages());

        Barang::create($data);

        return redirect()->route('barangs.index')->with('success', 'Barang baru berhasil ditambahkan!');
    }

    // FORM EDIT
    public function edit($id)
    {
        $barang = Barang::findOrFail($id);

        return view('barangs.edit', compact('barang'));
    }

    // UPDATE (dengan validasi)
    public function update(Request $request, $id)
    {
        $data = $request->validate(Barang::rules(), Barang::messages());

        Barang::findOrFail($id)->update($data);

        return redirect()->route('barangs.index')->with('success', 'Data barang berhasil diperbarui!');
    }

    // DELETE
    public function destroy($id)
    {
        Barang::findOrFail($id)->delete();

        return redirect()->route('barangs.index')->with('success', 'Data barang berhasil dihapus!');
    }
}
