<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Model Barang (Week 9) + aturan validasi bersama (Week 10)
 */
class Barang extends Model
{
    protected $table = 'barangs';

    protected $fillable = ['nama', 'kategori', 'stok', 'satuan', 'deskripsi'];

    public const KATEGORI = ['Makanan', 'Mandi', 'Kebersihan', 'P3K'];

    /** Aturan validasi dipakai oleh controller Web dan API (Task 02) */
    public static function rules(): array
    {
        return [
            'nama'      => 'required|string|max:100',
            'kategori'  => 'required|in:' . implode(',', self::KATEGORI),
            'stok'      => 'required|integer|min:0',
            'satuan'    => 'required|string|max:20',
            'deskripsi' => 'required|string',
        ];
    }

    public static function messages(): array
    {
        return [
            'nama.required'      => 'Nama wajib diisi.',
            'nama.max'           => 'Nama maksimal 100 karakter.',
            'kategori.required'  => 'Kategori wajib dipilih.',
            'kategori.in'        => 'Kategori tidak valid.',
            'stok.required'      => 'Stok wajib diisi.',
            'stok.integer'       => 'Stok harus berupa angka bulat.',
            'stok.min'           => 'Stok tidak boleh kurang dari 0.',
            'satuan.required'    => 'Satuan wajib diisi.',
            'satuan.max'         => 'Satuan maksimal 20 karakter.',
            'deskripsi.required' => 'Deskripsi wajib diisi.',
        ];
    }
}
