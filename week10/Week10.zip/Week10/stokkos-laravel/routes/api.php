<?php

use App\Http\Controllers\Api\BarangController;
use Illuminate\Support\Facades\Route;

// GET/POST /api/barangs, GET/PUT/PATCH/DELETE /api/barangs/{id}
Route::apiResource('barangs', BarangController::class);
