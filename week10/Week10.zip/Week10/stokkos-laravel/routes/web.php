<?php

use App\Http\Controllers\BarangController;
use Illuminate\Support\Facades\Route;

// Route hanya mengarahkan request ke Controller (tanpa logika di dalam route)
Route::get('/', fn () => redirect()->route('barangs.index'));

// index, create, store, edit, update, destroy -> nama route: barangs.*
Route::resource('barangs', BarangController::class)->except('show');
